# webextension--bootstrap-responsiveHelper

Show the bootstrap grid class currently active (XS, SM, MD, LG).

# Install
## Firefox
https://addons.mozilla.org/en-US/firefox/addon/bootstrap-responsive-helper/
